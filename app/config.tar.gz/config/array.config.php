<?php
$Qualities = array('CAM','SD','HD','Ultra HD');
$Reports = array(
'1' => __('O vídeo não está abrindo'),
'2' => __('O vídeo não existe mais'),
'3' => __('O video está travando'),
'4' => __('A Legenda Tem Problemas'),
'5' => __('Outros')
);
$Jquery = array(
THEME.'/js/jquery.min.js',
THEME.'/js/bootstrap.bundle.js',
THEME.'/js/jquery.lazy.js',
THEME.'/js/jquery.snackbar.js',
THEME.'/js/jquery.typeahead.js',
THEME.'/js/jquery.tmpl.js',
THEME.'/js/jquery.comment.js',
THEME.'/js/detail.js',
THEME.'/js/app.js'
);
$JqueryPlayer = array(
THEME.'/js/plyr.js',
THEME.'/js/plyr.hls.js',
);
