<?php
/**
* Default database config
* define("DB_HOST","localhost");
* define("DB_NAME","wp");
* define("DB_USER","root");
* define("DB_PASS","A99085831a.");
*/
define("DB_HOST","localhost");
define("DB_NAME","wp");
define("DB_USER","root");
define("DB_PASS","A99085831a.");
